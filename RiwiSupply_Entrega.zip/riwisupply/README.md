# RiwiSupply S.A.S. — Relational Database Project

## Project description
RiwiSupply S.A.S. is a company that distributes industrial supplies across
Colombia. Purchases, inventory, suppliers and warehouse movements were being
tracked in a single, unstandardized Excel file, causing duplicate suppliers,
inconsistent product names, and unreliable reports.

This project analyzes the original Excel dataset, normalizes it up to Third
Normal Form (3NF), designs an Entity-Relationship Model, and implements the
resulting relational database with sample data, CRUD scripts and business
queries.

## Technologies used
- PostgreSQL 16
- Python 3 (`openpyxl`) — used only to clean/transform the original Excel
  into normalized CSV files
- Graphviz — used to generate the Entity-Relationship diagram
- SQL (DDL / DML)

## Database engine used
PostgreSQL 16.

## Folder structure
```
riwisupply/
├── dataset_original/         Original Excel file provided by the company
├── 01_normalizacion/         Normalization analysis (1NF, 2NF, 3NF)
├── 02_MER/                   Entity-Relationship diagram (.dot, .png, .pdf)
├── 03_ddl/                   DDL script (tables, PKs, FKs, constraints)
├── 04_carga_datos/           Data cleaning script + generated CSV + load script
├── 05_dml/                   Insert / Update / Delete example scripts
├── 06_consultas/             The 6 required business queries
├── 07_evidencias/            Execution evidence (text output of the scripts)
└── README.md
```

## Explanation of the normalization process
The original file was a single flat sheet (`raw_data`) mixing supplier,
warehouse, product and movement data in every row, with the same supplier,
city, warehouse or category written in different ways (e.g. `"Aceros del
Norte S.A.S"`, `"Aceros del Norte"`, `"ACEROS NORTE"`).

The full explanation — problems found, canonical name dictionaries and the
1NF/2NF/3NF transformations — is documented in
[`01_normalizacion/normalizacion.md`](01_normalizacion/normalizacion.md).

In short:
- **1NF:** every cell holds a single value; a primary key was defined for
  every row; text values were standardized (removing duplicated
  spellings/abbreviations).
- **2NF:** attributes that depended only on part of the implicit composite
  key (supplier city, warehouse city, product category) were moved to their
  own tables.
- **3NF:** transitive dependencies were removed — e.g. `category` no longer
  lives inside the product row of the movement, it's a separate catalog
  referenced by `category_id`.

## Database structure
| Table | Purpose |
|---|---|
| `riwi_city` | Catalog of cities |
| `riwi_category` | Catalog of product categories |
| `riwi_supplier` | Suppliers, each linked to one city |
| `riwi_warehouse` | Warehouses, each linked to one city |
| `riwi_product` | Products, each linked to one category |
| `riwi_purchase` | Purchases made to a supplier (order code, product, qty, price) |
| `riwi_inventory_movement` | IN/OUT inventory movements per warehouse, optionally linked to a purchase |

All tables and columns use English names with the `riwi_` prefix, as
required.

## Entity Relationship Model
See [`02_MER/MER_RiwiSupply.pdf`](02_MER/MER_RiwiSupply.pdf) (or the `.png`
version) for the full diagram with entities, attributes, primary keys,
foreign keys and cardinalities.

## Instructions to create the database
1. Create the database and connect to it:
   ```bash
   psql -U postgres -c "CREATE DATABASE bd_luis_gonzalez_micaela;"
   psql -U postgres -d bd_luis_gonzalez_micaela -f 03_ddl/01_create_database.sql
   ```

## Instructions to load data
1. (Optional, already done) Regenerate the normalized CSV files from the
   original Excel:
   ```bash
   cd 04_carga_datos
   python3 limpiar_datos.py
   ```
2. Load the CSV files into the database (run from the `04_carga_datos`
   folder so the relative paths resolve):
   ```bash
   psql -U postgres -d bd_luis_gonzalez_micaela -f 02_load_data.sql
   ```

## Explanation of each SQL query
All queries are in [`06_consultas/consultas.sql`](06_consultas/consultas.sql),
execution evidence in
[`07_evidencias/evidencia_consultas.txt`](07_evidencias/evidencia_consultas.txt).

1. **Available stock per product** — sums IN movements minus OUT movements
   per product, so the inventory manager knows current stock.
2. **Inventory movements with product & warehouse detail** — joins
   movements with product and warehouse names for the logistics supervisor.
3. **Total purchased per supplier** — sums quantity and money spent per
   supplier, for the purchasing manager.
4. **Number of movements per warehouse** — counts movements grouped by
   warehouse, to spot the busiest ones.
5. **Product with the highest purchase volume** — the product with the most
   units purchased overall (highest rotation).
6. **Estimated inventory value per warehouse** — sums (IN − OUT) × unit
   price per warehouse, to estimate the monetary value stored in each one.

DML examples (insert supplier + product, update a supplier, delete a
product without movements) are in
[`05_dml/dml_operaciones.sql`](05_dml/dml_operaciones.sql), with evidence in
[`07_evidencias/evidencia_dml.txt`](07_evidencias/evidencia_dml.txt).

## Developer information
- **Full name:** Luis Gonzalez Davila
- **Clan:** Micaela
- **GitHub repository:** [https://github.com/luisgonzalezdavila77-cmyk/basedata.git]
