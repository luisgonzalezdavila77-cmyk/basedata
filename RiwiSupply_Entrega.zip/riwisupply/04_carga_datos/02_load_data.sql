-- =====================================================================
-- Carga de datos - RiwiSupply
-- Estrategia elegida: limpiar el Excel con un script Python
-- (limpiar_datos.py) que corrige nombres duplicados/inconsistentes y
-- genera un CSV por tabla ya normalizada. Luego se cargan con \copy
-- respetando el orden de las llaves foráneas (primero catálogos,
-- luego entidades, al final movimientos).
--
-- Ejecutar conectado a la base de datos del proyecto, por ejemplo:
--   psql -U postgres -d bd_luis_gonzalez_micaela -f 02_load_data.sql
-- =====================================================================

\copy riwi_city              FROM 'csv/riwi_city.csv'               WITH (FORMAT csv, HEADER true);
\copy riwi_category           FROM 'csv/riwi_category.csv'           WITH (FORMAT csv, HEADER true);
\copy riwi_supplier           FROM 'csv/riwi_supplier.csv'           WITH (FORMAT csv, HEADER true);
\copy riwi_warehouse          FROM 'csv/riwi_warehouse.csv'          WITH (FORMAT csv, HEADER true);
\copy riwi_product            FROM 'csv/riwi_product.csv'            WITH (FORMAT csv, HEADER true);
\copy riwi_purchase           FROM 'csv/riwi_purchase.csv'           WITH (FORMAT csv, HEADER true, NULL '\N');
\copy riwi_inventory_movement FROM 'csv/riwi_inventory_movement.csv' WITH (FORMAT csv, HEADER true, NULL '\N');

-- Ajustar las secuencias (SERIAL) después de cargar IDs manuales
SELECT setval('riwi_city_city_id_seq', (SELECT MAX(city_id) FROM riwi_city));
SELECT setval('riwi_category_category_id_seq', (SELECT MAX(category_id) FROM riwi_category));
SELECT setval('riwi_supplier_supplier_id_seq', (SELECT MAX(supplier_id) FROM riwi_supplier));
SELECT setval('riwi_warehouse_warehouse_id_seq', (SELECT MAX(warehouse_id) FROM riwi_warehouse));
SELECT setval('riwi_product_product_id_seq', (SELECT MAX(product_id) FROM riwi_product));
SELECT setval('riwi_purchase_purchase_id_seq', (SELECT MAX(purchase_id) FROM riwi_purchase));
SELECT setval('riwi_inventory_movement_movement_id_seq', (SELECT MAX(movement_id) FROM riwi_inventory_movement));
