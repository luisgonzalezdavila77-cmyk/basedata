"""
Limpia el archivo Excel original de RiwiSupply y genera 7 archivos CSV
ya normalizados (uno por tabla), listos para cargar con COPY / \\copy.

Uso:
    python3 limpiar_datos.py
"""
import openpyxl
import csv
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXCEL_PATH = os.path.join(BASE_DIR, "..", "dataset_original", "Dataset_RiwiSupply_-_Jornada_AM.xlsx")
OUT_DIR = os.path.join(BASE_DIR, "csv")
os.makedirs(OUT_DIR, exist_ok=True)

# --------------------------------------------------------------------
# 1) Diccionarios para estandarizar los textos "sucios" del Excel
# --------------------------------------------------------------------
CITY_MAP = {
    "cartagena": "Cartagena", "ctg": "Cartagena",
    "barranquilla": "Barranquilla", "barranquila": "Barranquilla", "b/quilla": "Barranquilla",
    "santa marta": "Santa Marta", "sta marta": "Santa Marta",
}

SUPPLIER_MAP = {
    "aceros del norte s.a.s": "Aceros del Norte S.A.S.",
    "aceros del norte": "Aceros del Norte S.A.S.",
    "aceros norte": "Aceros del Norte S.A.S.",
    "industriales sas": "Industriales S.A.S.",
    "industriales s.a.s": "Industriales S.A.S.",
    "suministros global sas": "Suministros Global S.A.S.",
}

WAREHOUSE_MAP = {
    "bodega central": "Bodega Central",
    "bod. central": "Bodega Central",
    "bodega costa": "Bodega Costa",
    "centro logistico norte": "Centro Logistico Norte",
}

PRODUCT_MAP = {
    "disco de corte 4.5": "Disco de Corte 4.5",
    "disco corte 4.5": "Disco de Corte 4.5",
    "guante nitrilo": "Guante de Nitrilo",
    "guantes de nitrilo": "Guante de Nitrilo",
    "electrodo e6013": "Electrodo E6013",
    "soldadura e6013": "Electrodo E6013",
    "casco industrial": "Casco Industrial",
}

CATEGORY_MAP = {
    "herramienta": "Herramientas",
    "herramientas": "Herramientas",
    "consumible": "Consumibles",
    "consumibles": "Consumibles",
    "epp": "EPP",
    "elementos protección": "EPP",
    "elementos proteccion": "EPP",
}

# Categoría "correcta" para cada producto ya limpio (por si el Excel trae
# la categoría inconsistente en alguna fila).
PRODUCT_CATEGORY = {
    "Disco de Corte 4.5": "Herramientas",
    "Electrodo E6013": "Consumibles",
    "Guante de Nitrilo": "EPP",
    "Casco Industrial": "EPP",
}

# Ciudad "correcta" de cada proveedor / bodega (según los datos observados)
SUPPLIER_CITY = {
    "Aceros del Norte S.A.S.": "Cartagena",
    "Industriales S.A.S.": "Barranquilla",
    "Suministros Global S.A.S.": "Santa Marta",
}
WAREHOUSE_CITY = {
    "Bodega Costa": "Santa Marta",
    "Centro Logistico Norte": "Cartagena",
    "Bodega Central": "Barranquilla",
}


def clean(value, mapping):
    key = str(value).strip().lower()
    return mapping.get(key, str(value).strip())


# --------------------------------------------------------------------
# 2) Leer el Excel
# --------------------------------------------------------------------
wb = openpyxl.load_workbook(EXCEL_PATH, data_only=True)
ws = wb["raw_data"]
rows = list(ws.iter_rows(values_only=True))
header, data_rows = rows[0], rows[1:]

cities, categories, suppliers, warehouses, products = {}, {}, {}, {}, {}
purchases, movements = [], []

for r in data_rows:
    (mv_date, sup_name, sup_city, wh_name, wh_city,
     prod_name, category, qty, unit_price, mv_type, po_code) = r

    sup_name = clean(sup_name, SUPPLIER_MAP)
    wh_name = clean(wh_name, WAREHOUSE_MAP)
    prod_name = clean(prod_name, PRODUCT_MAP)
    category = PRODUCT_CATEGORY.get(prod_name, clean(category, CATEGORY_MAP))

    sup_city_name = SUPPLIER_CITY.get(sup_name, clean(sup_city, CITY_MAP))
    wh_city_name = WAREHOUSE_CITY.get(wh_name, clean(wh_city, CITY_MAP))

    for c in (sup_city_name, wh_city_name):
        cities.setdefault(c, len(cities) + 1)
    categories.setdefault(category, len(categories) + 1)
    suppliers.setdefault(sup_name, {"id": len(suppliers) + 1, "city": sup_city_name})
    warehouses.setdefault(wh_name, {"id": len(warehouses) + 1, "city": wh_city_name})
    products.setdefault(prod_name, {"id": len(products) + 1, "category": category})

    if mv_type == "IN":
        purchases.append({
            "po_code": po_code, "supplier": sup_name, "product": prod_name,
            "date": mv_date, "qty": qty, "price": unit_price,
        })

    movements.append({
        "date": mv_date, "warehouse": wh_name, "product": prod_name,
        "po_code": po_code, "qty": qty, "price": unit_price, "type": mv_type,
    })

# --------------------------------------------------------------------
# 3) Escribir los CSV normalizados
# --------------------------------------------------------------------

def write_csv(filename, header, rows_iter):
    path = os.path.join(OUT_DIR, filename)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for row in rows_iter:
            w.writerow(row)
    print(f"  -> {filename} ({len(rows_iter)} filas)")


write_csv("riwi_city.csv", ["city_id", "city_name"],
          [(cid, name) for name, cid in cities.items()])

write_csv("riwi_category.csv", ["category_id", "category_name"],
          [(cid, name) for name, cid in categories.items()])

write_csv("riwi_supplier.csv", ["supplier_id", "supplier_name", "city_id"],
          [(v["id"], name, cities[v["city"]]) for name, v in suppliers.items()])

write_csv("riwi_warehouse.csv", ["warehouse_id", "warehouse_name", "city_id"],
          [(v["id"], name, cities[v["city"]]) for name, v in warehouses.items()])

write_csv("riwi_product.csv", ["product_id", "product_name", "category_id"],
          [(v["id"], name, categories[v["category"]]) for name, v in products.items()])

purchase_rows = []
purchase_id_by_code = {}
for i, p in enumerate(purchases, start=1):
    purchase_id_by_code[p["po_code"]] = i
    purchase_rows.append((
        i, p["po_code"], suppliers[p["supplier"]]["id"], products[p["product"]]["id"],
        p["date"], p["qty"], p["price"],
    ))
write_csv("riwi_purchase.csv",
          ["purchase_id", "purchase_order_code", "supplier_id", "product_id",
           "purchase_date", "quantity", "unit_price"],
          purchase_rows)

movement_rows = []
for i, m in enumerate(movements, start=1):
    purchase_id = purchase_id_by_code.get(m["po_code"]) if m["type"] == "IN" else None
    movement_rows.append((
        i, m["date"], warehouses[m["warehouse"]]["id"], products[m["product"]]["id"],
        purchase_id if purchase_id is not None else r"\N",
        m["qty"], m["price"], m["type"],
    ))
write_csv("riwi_inventory_movement.csv",
          ["movement_id", "movement_date", "warehouse_id", "product_id",
           "purchase_id", "quantity", "unit_price", "movement_type"],
          movement_rows)

print("\nListo. CSV generados en:", OUT_DIR)
