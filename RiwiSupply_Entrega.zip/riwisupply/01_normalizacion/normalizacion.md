# Análisis y Normalización de Datos - RiwiSupply S.A.S.

## 1. Estructura inicial

El archivo `Dataset_RiwiSupply_-_Jornada_AM.xlsx` trae **una sola tabla plana** (`raw_data`)
con estas 11 columnas:

| Columna | Descripción |
|---|---|
| MovementDate | Fecha del movimiento |
| SupplierName | Nombre del proveedor |
| SupplierCity | Ciudad del proveedor |
| Warehouse | Bodega |
| WarehouseCity | Ciudad de la bodega |
| ProductName | Producto |
| Category | Categoría del producto |
| Quantity | Cantidad |
| UnitPrice | Precio unitario |
| MovementType | IN (entrada) / OUT (salida) |
| PurchaseOrder | Código de la orden de compra |

Todo está mezclado en una sola fila: proveedor, ciudad, bodega, producto, categoría y
movimiento. Esto es típico de un archivo Excel manejado "a mano" por varias áreas.

## 2. Problemas identificados

Revisando fila por fila encontré estas inconsistencias:

### a) Proveedores duplicados con distinto formato
- `Aceros del Norte S.A.S`, `Aceros del Norte`, `ACEROS NORTE` → son el **mismo** proveedor.
- `Industriales SAS`, `Industriales S.A.S`, `INDUSTRIALES SAS` → son el **mismo** proveedor.
- `Suministros Global SAS` está escrito siempre igual (no tiene variantes en esta muestra).

### b) Ciudades escritas de formas distintas
- `Cartagena` / `Ctg`
- `Barranquilla` / `Barranquila` / `B/quilla`
- `Santa Marta` / `Sta Marta`

### c) Bodegas con nombres repetidos
- `Bodega Central` / `Bod. Central` → misma bodega.
- `Bodega Costa` y `Centro Logistico Norte` no tienen variantes.

### d) Productos con nombres inconsistentes
- `Disco de Corte 4.5` / `Disco Corte 4.5` → mismo producto.
- `Guante Nitrilo` / `Guantes de Nitrilo` → mismo producto.
- `Electrodo E6013` / `Soldadura E6013` → mismo producto (el electrodo de soldadura).
- `Casco Industrial` no tiene variantes.

### e) Categorías repetidas con nombre distinto
- `Herramienta` / `Herramientas`
- `Consumible` / `Consumibles`
- `EPP` / `Elementos Protección` → mismo grupo (Elementos de Protección Personal).

### f) Redundancia de información
La ciudad del proveedor se repite en cada fila donde aparece ese proveedor; lo mismo pasa
con la ciudad de la bodega, y con la categoría del producto. Si un día cambia la ciudad de
un proveedor, tocaría actualizar **muchas filas** en vez de una sola. Eso es una violación
de forma normal (dependencia transitiva).

## 3. Transformaciones aplicadas

### Primera Forma Normal (1FN)
- Cada celda tiene un solo valor (no hay listas ni datos combinados) → esto ya se cumplía.
- Se definió una clave primaria para cada fila (en este caso, cada movimiento tendrá su
  propio `movement_id`).
- Se estandarizaron los textos: se creó un **diccionario de nombres canónicos** para
  proveedores, ciudades, bodegas, productos y categorías, y se limpiaron mayúsculas,
  abreviaturas y espacios (ver script `04_carga_datos/limpiar_datos.py`).

### Segunda Forma Normal (2FN)
- Se identificó que la tabla plana tenía una clave compuesta implícita (fecha + proveedor +
  bodega + producto) y varios atributos dependían solo de una **parte** de esa clave:
  - La ciudad del proveedor depende solo del proveedor, no del movimiento completo.
  - La ciudad de la bodega depende solo de la bodega.
  - La categoría depende solo del producto.
- Por eso se separaron en tablas independientes: `riwi_supplier`, `riwi_warehouse`,
  `riwi_product`, `riwi_city`, `riwi_category`.

### Tercera Forma Normal (3FN)
- Se eliminaron las dependencias transitivas: por ejemplo, en la tabla original,
  `Category` dependía de `ProductName`, y `ProductName` dependía de la fila completa. Ahora
  `Category` vive en su propia tabla y `riwi_product` solo guarda una referencia
  (`category_id`), no el texto repetido.
- Lo mismo se hizo con `SupplierCity` (ahora `riwi_supplier.city_id`) y `WarehouseCity`
  (ahora `riwi_warehouse.city_id`).

## 4. Resultado final normalizado

Tablas resultantes (todas con prefijo `riwi_`, nombres en inglés):

1. **riwi_city** — catálogo único de ciudades.
2. **riwi_category** — catálogo único de categorías de producto.
3. **riwi_supplier** — proveedores, cada uno con una sola ciudad (FK a `riwi_city`).
4. **riwi_warehouse** — bodegas, cada una con una sola ciudad (FK a `riwi_city`).
5. **riwi_product** — productos, cada uno con una sola categoría (FK a `riwi_category`).
6. **riwi_purchase** — compras hechas a un proveedor (encabezado: proveedor + producto +
   cantidad + precio + fecha + código de orden).
7. **riwi_inventory_movement** — movimientos de inventario en cada bodega (IN/OUT),
   opcionalmente ligados a una compra.

Con esto ya no hay proveedores duplicados, ni ciudades escritas de formas distintas, ni
categorías repetidas: cada dato "maestro" vive en un solo lugar y las demás tablas solo
lo referencian por su `id`.
