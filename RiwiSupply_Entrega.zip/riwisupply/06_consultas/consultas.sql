-- =====================================================================
-- Consultas SQL - RiwiSupply
-- =====================================================================

-- ---------------------------------------------------------------------
-- Consulta 1: Stock disponible por producto
-- (para el encargado de inventarios: cuánto hay hoy de cada producto)
-- ---------------------------------------------------------------------
SELECT
    p.product_name,
    COALESCE(SUM(CASE WHEN m.movement_type = 'IN'  THEN m.quantity END), 0)
        - COALESCE(SUM(CASE WHEN m.movement_type = 'OUT' THEN m.quantity END), 0) AS stock_actual
FROM riwi_product p
LEFT JOIN riwi_inventory_movement m ON m.product_id = p.product_id
GROUP BY p.product_name
ORDER BY p.product_name;

-- ---------------------------------------------------------------------
-- Consulta 2: Movimientos de inventario con detalle de producto y bodega
-- (para el supervisor logístico)
-- ---------------------------------------------------------------------
SELECT
    m.movement_date,
    w.warehouse_name,
    p.product_name,
    m.movement_type,
    m.quantity,
    m.unit_price
FROM riwi_inventory_movement m
JOIN riwi_warehouse w ON w.warehouse_id = m.warehouse_id
JOIN riwi_product p   ON p.product_id  = m.product_id
ORDER BY m.movement_date;

-- ---------------------------------------------------------------------
-- Consulta 3: Total comprado por proveedor
-- (para el responsable de compras)
-- ---------------------------------------------------------------------
SELECT
    s.supplier_name,
    SUM(pu.quantity)                    AS unidades_compradas,
    SUM(pu.quantity * pu.unit_price)    AS total_comprado
FROM riwi_purchase pu
JOIN riwi_supplier s ON s.supplier_id = pu.supplier_id
GROUP BY s.supplier_name
ORDER BY total_comprado DESC;

-- ---------------------------------------------------------------------
-- Consulta 4: Cantidad de movimientos registrados por bodega
-- (para el administrador de operaciones)
-- ---------------------------------------------------------------------
SELECT
    w.warehouse_name,
    COUNT(m.movement_id) AS cantidad_movimientos
FROM riwi_warehouse w
LEFT JOIN riwi_inventory_movement m ON m.warehouse_id = w.warehouse_id
GROUP BY w.warehouse_name
ORDER BY cantidad_movimientos DESC;

-- ---------------------------------------------------------------------
-- Consulta 5: Producto con mayor volumen de compras
-- (para el analista, cuál producto rota más)
-- ---------------------------------------------------------------------
SELECT
    p.product_name,
    SUM(pu.quantity) AS unidades_compradas
FROM riwi_purchase pu
JOIN riwi_product p ON p.product_id = pu.product_id
GROUP BY p.product_name
ORDER BY unidades_compradas DESC
LIMIT 1;

-- ---------------------------------------------------------------------
-- Consulta 6: Valor total del inventario almacenado por bodega
-- (para el gerente de operaciones)
-- valor = (entradas - salidas) * precio promedio del producto en esa bodega
-- ---------------------------------------------------------------------
SELECT
    w.warehouse_name,
    SUM(
        CASE WHEN m.movement_type = 'IN'  THEN  m.quantity * m.unit_price
             WHEN m.movement_type = 'OUT' THEN -m.quantity * m.unit_price
        END
    ) AS valor_inventario_estimado
FROM riwi_inventory_movement m
JOIN riwi_warehouse w ON w.warehouse_id = m.warehouse_id
GROUP BY w.warehouse_name
ORDER BY valor_inventario_estimado DESC;
