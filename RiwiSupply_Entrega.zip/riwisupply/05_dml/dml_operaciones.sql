-- =====================================================================
-- Operaciones DML de ejemplo - RiwiSupply
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) INSERCIÓN: registrar un nuevo proveedor y un producto asociado
-- ---------------------------------------------------------------------

-- 1.1 Nuevo proveedor (ciudad ya existe: Barranquilla = city_id 2 en la
--     carga de ejemplo; si no existe, insértala primero en riwi_city)
INSERT INTO riwi_supplier (supplier_name, city_id)
VALUES ('Ferretería del Caribe S.A.S.',
        (SELECT city_id FROM riwi_city WHERE city_name = 'Barranquilla'));

-- 1.2 Nuevo producto (categoría ya existente: Herramientas)
INSERT INTO riwi_product (product_name, category_id)
VALUES ('Taladro Percutor 1/2',
        (SELECT category_id FROM riwi_category WHERE category_name = 'Herramientas'));

-- 1.3 (Opcional) registrar la compra de ese producto a ese proveedor
INSERT INTO riwi_purchase (purchase_order_code, supplier_id, product_id,
                            purchase_date, quantity, unit_price)
VALUES ('PO-2001',
        (SELECT supplier_id FROM riwi_supplier WHERE supplier_name = 'Ferretería del Caribe S.A.S.'),
        (SELECT product_id FROM riwi_product WHERE product_name = 'Taladro Percutor 1/2'),
        CURRENT_DATE, 25, 185000.00);

-- ---------------------------------------------------------------------
-- 2) ACTUALIZACIÓN: modificar información de un proveedor existente
-- ---------------------------------------------------------------------

UPDATE riwi_supplier
SET supplier_name = 'Aceros del Norte S.A.S. (Sucursal Cartagena)'
WHERE supplier_name = 'Aceros del Norte S.A.S.';

-- ---------------------------------------------------------------------
-- 3) ELIMINACIÓN: borrar un producto que NO tenga movimientos asociados
-- ---------------------------------------------------------------------

-- Como el producto "Taladro Percutor 1/2" recién se creó y aún no tiene
-- movimientos en riwi_inventory_movement, se puede borrar sin problema.
-- La restricción de llave foránea impide borrar un producto que sí tenga
-- movimientos (ver prueba comentada abajo).

DELETE FROM riwi_purchase WHERE purchase_order_code = 'PO-2001'; -- se quita la compra primero
DELETE FROM riwi_product WHERE product_name = 'Taladro Percutor 1/2';

-- Prueba de integridad (debe FALLAR con error de FK porque sí tiene movimientos):
-- DELETE FROM riwi_product WHERE product_name = 'Disco de Corte 4.5';
