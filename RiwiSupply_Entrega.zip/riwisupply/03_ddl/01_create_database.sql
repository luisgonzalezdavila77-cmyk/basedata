-- =====================================================================
-- RiwiSupply S.A.S. - Script DDL
-- Motor: PostgreSQL 16
-- Nombre de la base de datos: bd_luis_gonzalez_micaela
-- (Luis Gonzalez Davila - Clan Micaela)
-- =====================================================================

-- 1) Crear la base de datos (ejecutar conectado a "postgres")
-- CREATE DATABASE bd_luis_gonzalez_micaela;
-- \c bd_luis_gonzalez_micaela

-- 2) Catálogos base -----------------------------------------------------

CREATE TABLE riwi_city (
    city_id     SERIAL PRIMARY KEY,
    city_name   VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE riwi_category (
    category_id     SERIAL PRIMARY KEY,
    category_name   VARCHAR(80) NOT NULL UNIQUE
);

-- 3) Entidades principales ----------------------------------------------

CREATE TABLE riwi_supplier (
    supplier_id     SERIAL PRIMARY KEY,
    supplier_name   VARCHAR(150) NOT NULL UNIQUE,
    city_id         INTEGER NOT NULL,
    CONSTRAINT fk_supplier_city
        FOREIGN KEY (city_id) REFERENCES riwi_city (city_id)
);

CREATE TABLE riwi_warehouse (
    warehouse_id    SERIAL PRIMARY KEY,
    warehouse_name  VARCHAR(150) NOT NULL UNIQUE,
    city_id         INTEGER NOT NULL,
    CONSTRAINT fk_warehouse_city
        FOREIGN KEY (city_id) REFERENCES riwi_city (city_id)
);

CREATE TABLE riwi_product (
    product_id      SERIAL PRIMARY KEY,
    product_name    VARCHAR(150) NOT NULL UNIQUE,
    category_id     INTEGER NOT NULL,
    CONSTRAINT fk_product_category
        FOREIGN KEY (category_id) REFERENCES riwi_category (category_id)
);

-- 4) Compras --------------------------------------------------------------

CREATE TABLE riwi_purchase (
    purchase_id         SERIAL PRIMARY KEY,
    purchase_order_code VARCHAR(20) NOT NULL UNIQUE,
    supplier_id         INTEGER NOT NULL,
    product_id          INTEGER NOT NULL,
    purchase_date       DATE NOT NULL,
    quantity            INTEGER NOT NULL CHECK (quantity > 0),
    unit_price          NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
    CONSTRAINT fk_purchase_supplier
        FOREIGN KEY (supplier_id) REFERENCES riwi_supplier (supplier_id),
    CONSTRAINT fk_purchase_product
        FOREIGN KEY (product_id) REFERENCES riwi_product (product_id)
);

-- 5) Movimientos de inventario ---------------------------------------------

CREATE TABLE riwi_inventory_movement (
    movement_id     SERIAL PRIMARY KEY,
    movement_date   DATE NOT NULL,
    warehouse_id    INTEGER NOT NULL,
    product_id      INTEGER NOT NULL,
    purchase_id     INTEGER NULL,
    quantity        INTEGER NOT NULL CHECK (quantity > 0),
    unit_price      NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
    movement_type   VARCHAR(3) NOT NULL CHECK (movement_type IN ('IN', 'OUT')),
    CONSTRAINT fk_movement_warehouse
        FOREIGN KEY (warehouse_id) REFERENCES riwi_warehouse (warehouse_id),
    CONSTRAINT fk_movement_product
        FOREIGN KEY (product_id) REFERENCES riwi_product (product_id),
    CONSTRAINT fk_movement_purchase
        FOREIGN KEY (purchase_id) REFERENCES riwi_purchase (purchase_id)
);

-- Índices de apoyo para las consultas más usadas
CREATE INDEX idx_movement_warehouse ON riwi_inventory_movement (warehouse_id);
CREATE INDEX idx_movement_product   ON riwi_inventory_movement (product_id);
CREATE INDEX idx_purchase_supplier  ON riwi_purchase (supplier_id);
